## Install Dependencies

```shell
npm install
```

## Start MongoDB

```shell
mongod
```

## Run Application

```shell
npm start
```
