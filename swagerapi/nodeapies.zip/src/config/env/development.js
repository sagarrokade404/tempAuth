export const devConfig = {
  secret: 'from_arc',
};
